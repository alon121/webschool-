# jQuery-exercise-1

learn Jquery Basic & practice
For Students
