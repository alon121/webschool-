function ShowEX() {
    $("#target1").css("background-color", "pink")
}